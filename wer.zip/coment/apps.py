from django.apps import AppConfig


class ComentConfig(AppConfig):
    name = 'coment'
