from django.apps import AppConfig


class NyastulConfig(AppConfig):
    name = 'nyastul'
