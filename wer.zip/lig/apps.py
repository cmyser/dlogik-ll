from django.apps import AppConfig


class LigConfig(AppConfig):
    name = 'lig'
